<div class="dashboard_widget_msg">
    <p
        class="smiley"
        aria-hidden="true"
    ></p>
    <p>{{ isset($message) ? $message : trans('core/base::tables.no_data') }}</p>
</div>
