<div class="form-group mb-3 col-12">
    <div class="form-actions">
        <div class="btn-set text-center">
            <button
                class="btn btn-success"
                name="submit"
                type="submit"
                value="submit"
            >
                <i class="fa fa-check-circle"></i> {{ trans('core/acl::users.update') }}
            </button>
        </div>
    </div>
</div>
