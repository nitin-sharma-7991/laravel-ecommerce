<?php

namespace Botble\Media\Repositories\Caches;

use Botble\Media\Repositories\Eloquent\MediaSettingRepository;

/**
 * @deprecated
 */
class MediaSettingCacheDecorator extends MediaSettingRepository
{
}
