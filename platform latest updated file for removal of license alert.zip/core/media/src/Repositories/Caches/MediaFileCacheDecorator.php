<?php

namespace Botble\Media\Repositories\Caches;

use Botble\Media\Repositories\Eloquent\MediaFileRepository;

/**
 * @deprecated
 */
class MediaFileCacheDecorator extends MediaFileRepository
{
}
