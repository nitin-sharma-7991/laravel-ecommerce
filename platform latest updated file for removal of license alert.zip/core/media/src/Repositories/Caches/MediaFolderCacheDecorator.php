<?php

namespace Botble\Media\Repositories\Caches;

use Botble\Media\Repositories\Eloquent\MediaFolderRepository;

/**
 * @deprecated
 */
class MediaFolderCacheDecorator extends MediaFolderRepository
{
}
