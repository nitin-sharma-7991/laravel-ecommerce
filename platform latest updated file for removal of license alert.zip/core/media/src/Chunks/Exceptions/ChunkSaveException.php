<?php

namespace Botble\Media\Chunks\Exceptions;

use Exception;

class ChunkSaveException extends Exception
{
}
