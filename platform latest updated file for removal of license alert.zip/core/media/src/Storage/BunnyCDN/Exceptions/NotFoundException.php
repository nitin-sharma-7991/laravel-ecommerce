<?php

namespace Botble\Media\Storage\BunnyCDN\Exceptions;

class NotFoundException extends BunnyCDNException
{
}
