<?php

namespace Botble\Media\Storage\BunnyCDN\Exceptions;

class DirectoryNotEmptyException extends BunnyCDNException
{
}
