<?php

namespace Botble\Media\Storage\BunnyCDN\Exceptions;

use Exception;

class BunnyCDNException extends Exception
{
}
